insert into student values(11,'ram');
insert into student values(12,'ramesh');