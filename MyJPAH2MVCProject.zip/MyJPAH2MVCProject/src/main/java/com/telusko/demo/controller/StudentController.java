package com.telusko.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.telusko.demo.dao.StudentRepo;
import com.telusko.demo.model.Student;

@Controller
public class StudentController {
	
    @Autowired
	StudentRepo studentrepo;
    
	@RequestMapping("/")
	public String home(){
		return "Home.jsp";
	}
	
	@RequestMapping("/addStudent")
	public String home2(Student student){
		
		studentrepo.save(student);
		return "Home.jsp";
	}
	
	@RequestMapping("/showStudent")
	public ModelAndView home3(@RequestParam("sid") int sid){
		 
		ModelAndView mv =new ModelAndView("showStudent.jsp");
		Student student=studentrepo.findById(sid).orElse(new Student());
		mv.addObject(student);
		return mv;
	}
	
	
}
