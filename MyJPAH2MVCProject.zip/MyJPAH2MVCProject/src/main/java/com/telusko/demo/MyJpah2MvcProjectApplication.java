package com.telusko.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyJpah2MvcProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyJpah2MvcProjectApplication.class, args);
	}

}
