package com.telusko.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.telusko.demo.model.Student;

public interface StudentRepo extends CrudRepository<Student,Integer>{

}
